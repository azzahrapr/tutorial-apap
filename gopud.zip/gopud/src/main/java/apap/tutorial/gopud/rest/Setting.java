package apap.tutorial.gopud.rest;

public class Setting {
    final public static String restoranUrl = "https://26a02f16-3527-456f-a371-4d4872e29f29.mock.pstmn.io";
    final public static String chefUrl = "https://1b9f0f25-7f24-4c84-bc83-3ded0830c3f8.mock.pstmn.io/api/v1/restoran/chef?nama=Juni";
}
